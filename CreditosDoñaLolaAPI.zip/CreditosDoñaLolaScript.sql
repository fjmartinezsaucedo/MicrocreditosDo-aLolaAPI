--Creacion de la base de datos
create database creditosdo�alola
use creditosdo�alola

--Creacion de la tabla cliente
create table Clientes(
	IdCliente int identity primary key,
	Nombre varchar(30),
	ApellidoPaterno varchar (30),
	ApellidoMaterno varchar (30),
	CantidadPrestada int,
	Telefono varchar(30),
	Email varchar (40),
	FechaPrestamo varchar (40),
	DiaCobro int,
	MesPrestamo int,
	Intereses int
)

drop table Clientes

--��Creacion de procedimientos almacenados a ultilizar!!--

--Procedimiento de consulta
Create procedure sp_Consultar
as begin
	select * from Clientes
end

--Procedimiento especifico de consulta con ID
Create procedure sp_ConsultaId(
@IdCliente int
)
as begin
	select * from Clientes where IdCliente = @IdCliente
end

--Procedimiento para ingresar un nuevo cliente dentro de la tabla
Create procedure sp_Crear(
@Nombre varchar (50),
@ApellidoPaterno varchar (50),
@ApellidoMaterno varchar (50),
@CantidadPrestada int,
@Telefono varchar (30),
@Email varchar (40),
@FechaPrestamo varchar (40),
@DiaCobro int,
@MesPrestamo int,
@Intereses int
)
as begin
	insert into Clientes (Nombre, ApellidoPaterno, ApellidoMaterno, CantidadPrestada, Telefono, Email, FechaPrestamo, DiaCobro, MesPrestamo, Intereses) 
		values 
	(@Nombre, @ApellidoPaterno, @ApellidoMaterno, @CantidadPrestada, @Telefono, @Email, @FechaPrestamo, @DiaCobro, @MesPrestamo, @Intereses)
end

--Procedimiento para editar la informacion del cliente dentro de la tabla
Create procedure sp_Editar(
@IdCliente int,
@Nombre varchar (50),
@ApellidoPaterno varchar (50),
@ApellidoMaterno varchar (50),
@CantidadPrestada int,
@Telefono varchar (30),
@Email varchar (40),
@FechaPrestamo varchar (40),
@DiaCobro int,
@MesPrestamo int,
@Intereses int
)
as begin
	update Clientes set 
		Nombre = @Nombre, 
		ApellidoPaterno = @ApellidoPaterno, 
		ApellidoMaterno = @ApellidoMaterno,
		CantidadPrestada = @CantidadPrestada,
		Telefono = @Telefono,
		Email = @Email,
		FechaPrestamo = @FechaPrestamo,
		DiaCobro = @DiaCobro,
		MesPrestamo = @MesPrestamo,
		Intereses = @Intereses

		where IdCliente = @IdCliente
end

--Procedimiento para eliminar un cliente dentro de la tabla
Create procedure sp_Eliminar(
@IdCliente int
)
as begin	
	delete from Clientes where IdCliente = @IdCliente
end

select * from Clientes

select * from Clientes where IdCliente = 1