﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CreditosDoñaLolaAPI.Models;
using System;

namespace CreditosDoñaLolaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {

        public readonly CreditosdoñalolaContext _cdlcontext;

        public ClienteController(CreditosdoñalolaContext _context)
        {
            _cdlcontext = _context;
        }

        [HttpGet]
        [Route("Consulta")]
        public IActionResult Consulta() 
        {
            List<Cliente> lista = new List<Cliente>();

            try
            {
                lista = _cdlcontext.Clientes.ToList();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", response = lista });
            }
            catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message, response = lista });
            }
        }

        [HttpGet]
        [Route("Obtener/{IdCliente:int}")]
        public IActionResult Obtener(int IdCliente)
        {
            Cliente oCliente = _cdlcontext.Clientes.Find(IdCliente);

            if (oCliente == null)
            {
                return BadRequest("Cliente no encontrado");
            }

            try
            {                                
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", response = oCliente });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message, response = oCliente });
            }
        }

        [HttpPost]
        [Route("Guardar")]
        public IActionResult Guardar([FromBody] Cliente objeto)
        {
            try
            {
                _cdlcontext.Clientes.Add(objeto);
                _cdlcontext.SaveChanges();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message });
            }
        }

        [HttpPut]
        [Route("Editar")]
        public IActionResult Editar([FromBody] Cliente objeto)
        {
            Cliente oCliente = _cdlcontext.Clientes.Find(objeto.IdCliente);

            if (oCliente == null)
            {
                return BadRequest("Cliente no encontrado");
            }

            try
            {
                oCliente.Nombre = objeto.Nombre is null ? oCliente.Nombre : objeto.Nombre;
                oCliente.ApellidoPaterno = objeto.ApellidoPaterno is null ? oCliente.ApellidoPaterno : objeto.ApellidoPaterno;
                oCliente.ApellidoMaterno = objeto.ApellidoMaterno is null ? oCliente.ApellidoMaterno : objeto.ApellidoMaterno;
                oCliente.CantidadPrestada = objeto.CantidadPrestada is null ? oCliente.CantidadPrestada : objeto.CantidadPrestada;
                oCliente.Telefono = objeto.Telefono is null ? oCliente.Telefono : objeto.Telefono;
                oCliente.Email = objeto.Email is null ? oCliente.Email : objeto.Email;
                oCliente.FechaPrestamo = objeto.FechaPrestamo is null ? oCliente.FechaPrestamo : objeto.FechaPrestamo;
                oCliente.DiaCobro = objeto.DiaCobro is null ? oCliente.DiaCobro : objeto.DiaCobro;
                oCliente.MesPrestamo = objeto.MesPrestamo is null ? oCliente.MesPrestamo : objeto.MesPrestamo;
                oCliente.Intereses = objeto.Intereses is null ? oCliente.Intereses : objeto.Intereses;

                _cdlcontext.Clientes.Update(oCliente);
                _cdlcontext.SaveChanges();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message });
            }
        }

        [HttpDelete]
        [Route("Eliminar/{IdCliente:int}")]
        public IActionResult Eliminar(int IdCliente)
        {
            Cliente oCliente = _cdlcontext.Clientes.Find(IdCliente);

            if (oCliente == null)
            {
                return BadRequest("Cliente no encontrado");
            }

            try
            {                
                _cdlcontext.Clientes.Remove(oCliente);
                _cdlcontext.SaveChanges();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message });
            }
        }
    }
}
